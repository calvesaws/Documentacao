import sys
from Services import MensagemService

def lambda_handler(event, context):
   
   id = event['pathParameters']['id']
  
   mensagem_obj = MensagemService.MensagemService();

   mensagem_excluida = mensagem_obj.ExcluirMensagemService(id);
   
   return  mensagem_excluida

