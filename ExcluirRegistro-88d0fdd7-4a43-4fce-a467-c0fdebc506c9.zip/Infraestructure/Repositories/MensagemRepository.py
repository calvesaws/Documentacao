import boto3
import string

class MensagemRepository():
   
    def ExcluirMensagem(self,id:string):
             
        try:
           cliente = boto3.resource('dynamodb')
           tabela = 'Dados'
          
           tabela = cliente.Table(tabela)
           
           deletar = tabela.delete_item(Key = {'Id' : id})
           
           
           return True
          
        except: 
            raise Exception("Erro ao tentar deletar o documento no Dynamodb")
           
