
import json
from Infraestructure.Repositories import MensagemRepository

class MensagemService():

  def ExcluirMensagemService(self,id):
    
     mensagem_repository = MensagemRepository.MensagemRepository();


     if mensagem_repository.ExcluirMensagem(id):       
          
        mensagem = {
           "mensagem": "Mensagem excluída com sucesso!"
               }
        return {
       
         'statusCode': 200,
        
         "headers": {
              "Access-Control-Allow-Origin": "*",
              "Access-Control-Allow-Header": "Content-Type",
              "Access-Control-Allow-Methods": "OPTIONS,DEL"
       },
         'body': json.dumps(mensagem)

       }
         