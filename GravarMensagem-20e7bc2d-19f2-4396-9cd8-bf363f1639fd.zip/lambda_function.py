import json
import uuid
import boto3
import rsa
import datetime;

def lambda_handler(event, context):
    client = boto3.resource('dynamodb')
    table = client.Table('Dados')
    mensagem =  event['mensagem']
    senha =  event['senha']
    tempo = event['tempo']
    id = str(uuid.uuid4())
    visualizacoes_max = event['visualizacoes_max']
    addhour= datetime.timedelta(minutes = tempo)
    time = datetime.datetime.now() + addhour
    time_body = str(time.strftime("%d-%m-%Y %H:%M:%S"))
    time = int(time.timestamp())
    


    with open('public_key.pem', mode='rb') as public_file:
      key_data = public_file.read()
      public_key = rsa.PublicKey.load_pkcs1(key_data,'PEM');
      
    encMessage = rsa.encrypt(mensagem.encode(),  
                         public_key) 
  
    table.put_item(Item= {'Id': id,'mensagem': encMessage,'senha': senha, 'tempo': time, 'visualizacoes_max' : visualizacoes_max, 'visualizacoes': 0})
    
    
    

    dict = {
     "id" : id,
     "time" : time_body,
     "visualizacoes_max" : visualizacoes_max
     
     
    }
    retorno = {
     "statusCode": 200,
     "headers": {
      "Access-Control-Allow-Origin": "*",
       "Access-Control-Allow-Header": "Content-Type",
              "Access-Control-Allow-Methods": "OPTIONS,POST,GET"

     },
    
      "body" : dict
    }
   
    return retorno
   
 