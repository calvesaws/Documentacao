

import rsa
#from rsa.key import PrivateKey
  
#publicKey, privateKey = rsa.newkeys(1024) 
message = "hello geeks"

#publica = publicKey.save_pkcs1().decode();
##publica = publicKey.save_pkcs1();
#print(publica);
#privada = privateKey.save_pkcs1().decode();
#print(privada);

with open('public_key.pem', mode='rb') as public_file:
    key_data = public_file.read()
    #print(key_data);
    public_key = rsa.PublicKey.load_pkcs1(key_data,'PEM');


  
encMessage = rsa.encrypt(message.encode(),  
                         public_key) 
  
print("original string: ", message) 
print("encrypted string: ", encMessage) 


with open('private_key.pem', mode='rb') as private_file:
    key_data = private_file.read()
    print(key_data);
    private_key = rsa.PrivateKey.load_pkcs1(key_data,'PEM');
  
decMessage = rsa.decrypt(encMessage, private_key).decode() 
  
print("decrypted string: ", decMessage) 
