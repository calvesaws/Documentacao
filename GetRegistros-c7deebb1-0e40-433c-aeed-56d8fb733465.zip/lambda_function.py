import json
import boto3
import datetime
import rsa

def lambda_handler(event, context):
     
     client = boto3.resource('dynamodb')
     table = client.Table('Dados')
     id = event['pathParameters']['id']
     senhauser = event['queryStringParameters']['senha']
     resp = table.get_item(
           Key={
               'Id' : id,
           }
        )
     
     try:
         print(resp['Item']['mensagem'].value)
     except:
         error = {
         "mensagem": "Mensagem não existe"
           }
         return {
          'statusCode': 200,
          "headers": {
         "Access-Control-Allow-Origin": "*",
         "Access-Control-Allow-Header": "Content-Type",
         "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
            },
         'body': json.dumps(error)
             }
         
        
     encmensagem= (resp['Item']['mensagem'].value);
     senha= (resp['Item']['senha'])
     visualizacoes= str((resp['Item']['visualizacoes']))
     visualizacoes_max = str((resp['Item']['visualizacoes_max']))

     with open('private_key.pem', mode='rb') as private_file:
       key_data = private_file.read()
       private_key = rsa.PrivateKey.load_pkcs1(key_data,'PEM');
      
    
     mensagem = rsa.decrypt(encmensagem, private_key).decode() 
  
      
     epoch_time= (resp['Item']['tempo'])
     
     now = datetime.datetime.now()
     
     date_time = datetime.datetime.fromtimestamp( epoch_time )  
     
     time = str(date_time.strftime("%d-%m-%Y %H:%M:%S"))


     

     if now > date_time:
        error = {
         "mensagem": "Mensagem foi expirada"
        }
        return {
         'statusCode': 200,
       "headers": {
      "Access-Control-Allow-Origin": "*",
       "Access-Control-Allow-Header": "Content-Type",
              "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
       },
         'body': json.dumps(error)
             }
     else:
         if senha == senhauser:
           visualizacoes = int(visualizacoes) + 1
           if visualizacoes <= int(visualizacoes_max):
              teste = {
                "mensagem" : mensagem,
                "senha": senha,
                "visualizacoes": visualizacoes,
                "visualizacoes_max": visualizacoes_max,
                "date_time" : time
                 }
              table.update_item(
                  Key={'Id': id },
                  UpdateExpression="set visualizacoes = :r",
                  ExpressionAttributeValues={
                  ':r': visualizacoes,                                  
                       },
                  ReturnValues="UPDATED_NEW"
                )
             
              return {
                   'statusCode': 200,
                                "headers": {
      "Access-Control-Allow-Origin": "*",
       "Access-Control-Allow-Header": "Content-Type",
              "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
       },
                  'body': json.dumps(teste)
               }
           else:
               
                  error = {
                      "mensagem": "Mensagem passou do limite de visualizacao"
                       }
                  return {
                       'statusCode': 200,
                       'body': json.dumps(error)
                    }
              
         else:
           
            senhaerro = {
              "mensagem" : "Senha Incorreta",
          
              }
            return {
                'statusCode': 200,
                
                "headers": {
      "Access-Control-Allow-Origin": "*",
       "Access-Control-Allow-Header": "Content-Type",
              "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
       },
                'body': json.dumps(senhaerro)
                  }
   
     
   
   
