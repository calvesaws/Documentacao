import string

class Evento():
    
  def __init__(self, id: string, senha: string):    
    
    self.id = id
    self.senha = senha
    
    id: string
    senha: string
    





