import json
import uuid
import boto3


def lambda_handler(event, context):
    client = boto3.resource('dynamodb')
    table = client.Table('Dados')
    id = event['pathParameters']['id']    
    
    delete = table.delete_item(Key = {'Id': id})
    
    mensagem = {
         "mensagem": "Mensagem excluída com sucesso!"
           }
    
    return {
        'statusCode': 200,
        
         "headers": {
      "Access-Control-Allow-Origin": "*",
       "Access-Control-Allow-Header": "Content-Type",
              "Access-Control-Allow-Methods": "OPTIONS,POST,GET,DEL"
       },
        'body': json.dumps(mensagem)
    }
